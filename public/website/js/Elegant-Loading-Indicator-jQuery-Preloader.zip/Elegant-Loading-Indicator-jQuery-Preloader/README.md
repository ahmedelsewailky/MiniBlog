# jquery.preloader v1.0.1
A small jQuery plug-in is designed for display loading animation when some process is running just by selecting any container.
The plugin has the methods and options for easy controlling the displaying.

Plugin includes SCSS where determines basic styles of blocks, animation, etc.

**Instructions**

Here https://github.com/mpchelnikov/jquery.preloader/wiki you can get all info you need

**Demo**

https://codepen.io/mpchelnikov/pen/qRXewR